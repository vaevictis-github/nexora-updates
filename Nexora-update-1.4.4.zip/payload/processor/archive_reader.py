"""Leitura controlada de XMLs enviados individualmente, em ZIP ou 7z."""
from pathlib import Path, PurePosixPath
from tempfile import TemporaryDirectory
import zipfile

MAX_XMLS = 15000
MAX_SINGLE_XML = 15 * 1024 * 1024
MAX_TOTAL_XML = 350 * 1024 * 1024


class ArchiveError(ValueError):
    pass


def _checked_name(name):
    normalized = name.replace("\\", "/")
    path = PurePosixPath(normalized)
    if (not normalized or normalized.startswith("/") or
            any(part in ("..", "") for part in normalized.split("/")) or
            ":" in normalized.split("/")[0]):
        raise ArchiveError(f"Caminho inseguro dentro do arquivo: {name}")
    return normalized


def _zip_documents(stream, label):
    try:
        with zipfile.ZipFile(stream) as archive:
            entries = [info for info in archive.infolist()
                       if not info.is_dir() and info.filename.lower().endswith(".xml")]
            if len(entries) > MAX_XMLS:
                raise ArchiveError(f"ZIP contém mais de {MAX_XMLS} XMLs")
            if not entries:
                raise ArchiveError("Nenhum XML encontrado no arquivo ZIP")
            total = 0
            for info in entries:
                _checked_name(info.filename)
                if info.file_size > MAX_SINGLE_XML:
                    raise ArchiveError(f"XML muito grande: {info.filename}")
                total += info.file_size
                if total > MAX_TOTAL_XML:
                    raise ArchiveError("ZIP excede o limite de XMLs descompactados (350 MB)")
                with archive.open(info) as source:
                    data = source.read(MAX_SINGLE_XML + 1)
                if len(data) > MAX_SINGLE_XML:
                    raise ArchiveError(f"XML excede o limite: {info.filename}")
                yield f"{label} / {info.filename}", data
    except (zipfile.BadZipFile, RuntimeError) as exc:
        raise ArchiveError(f"ZIP inválido ou protegido: {exc}") from exc


def _7z_documents(stream, label):
    try:
        import py7zr
    except ImportError as exc:
        raise ArchiveError("Biblioteca py7zr não instalada; recompile usando requirements-desktop.txt") from exc
    try:
        with TemporaryDirectory(prefix="nexora-7z-") as temp:
            root = Path(temp).resolve()
            with py7zr.SevenZipFile(stream, mode="r") as archive:
                if archive.needs_password():
                    raise ArchiveError("Arquivos 7z protegidos por senha não são suportados")
                entries = [info for info in archive.list()
                           if not info.is_directory and info.filename.lower().endswith(".xml")]
                if len(entries) > MAX_XMLS:
                    raise ArchiveError(f"7z contém mais de {MAX_XMLS} XMLs")
                total = 0
                for info in entries:
                    _checked_name(info.filename)
                    if getattr(info, "is_symlink", False):
                        raise ArchiveError("Links simbólicos não são permitidos no 7z")
                    size = getattr(info, "uncompressed", None)
                    if size is None:
                        raise ArchiveError("Tamanho descompactado desconhecido no 7z")
                    if size > MAX_SINGLE_XML:
                        raise ArchiveError(f"XML muito grande: {info.filename}")
                    total += size
                    if total > MAX_TOTAL_XML:
                        raise ArchiveError("7z excede o limite de XMLs descompactados (350 MB)")
                # Extrai apenas entradas XML selecionadas e previamente verificadas.
                if not entries:
                    raise ArchiveError("Nenhum XML encontrado no arquivo 7z")
                archive.extract(path=temp, targets=[entry.filename for entry in entries])
            for info in entries:
                target = (root / info.filename).resolve()
                if not target.is_relative_to(root) or not target.is_file():
                    raise ArchiveError(f"Caminho inseguro no 7z: {info.filename}")
                with target.open("rb") as source:
                    data = source.read(MAX_SINGLE_XML + 1)
                if len(data) > MAX_SINGLE_XML:
                    raise ArchiveError(f"XML excede o limite: {info.filename}")
                yield f"{label} / {info.filename}", data
    except ArchiveError:
        raise
    except Exception as exc:
        raise ArchiveError(f"Não foi possível abrir o 7z: {exc}") from exc


def iter_xml_documents(upload):
    name = upload.filename or "arquivo"
    extension = Path(name).suffix.lower()
    if extension == ".xml":
        content = upload.stream.read(MAX_SINGLE_XML + 1)
        if len(content) > MAX_SINGLE_XML:
            raise ArchiveError(f"XML excede o limite de {MAX_SINGLE_XML // (1024 * 1024)} MB")
        yield name, content
    elif extension == ".zip":
        yield from _zip_documents(upload.stream, name)
    elif extension == ".7z":
        yield from _7z_documents(upload.stream, name)
    else:
        raise ArchiveError("Formato inválido. Use XML, ZIP ou 7z")
