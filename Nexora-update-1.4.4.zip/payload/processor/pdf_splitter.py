"""Divisão de PDFs em páginas individuais, adaptada do split.py do usuário."""
from io import BytesIO
from pypdf import PdfReader, PdfWriter


def split_pdf_pages(data: bytes) -> list[bytes]:
    reader = PdfReader(BytesIO(data), strict=False)
    if reader.is_encrypted:
        try:
            if reader.decrypt("") == 0:
                raise ValueError("PDF protegido por senha")
        except Exception as exc:
            raise ValueError("PDF protegido por senha") from exc
    if not reader.pages:
        raise ValueError("PDF não contém páginas")
    output = []
    for page in reader.pages:
        writer = PdfWriter()
        writer.add_page(page)
        stream = BytesIO()
        writer.write(stream)
        output.append(stream.getvalue())
    return output
