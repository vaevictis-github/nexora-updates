from decimal import Decimal, InvalidOperation
import xml.etree.ElementTree as ET


def local_name(tag):
    """Remove namespace XML: {namespace}Tag -> Tag."""
    return tag.rsplit("}", 1)[-1]


def child_text(element, wanted_name, default=""):
    for child in element:
        if local_name(child.tag) == wanted_name:
            return (child.text or "").strip()
    return default


def to_decimal(value, field_name):
    try:
        return Decimal(str(value).strip().replace(",", "."))
    except (InvalidOperation, ValueError):
        raise ValueError(f"Valor inválido no campo {field_name}: {value!r}")


def parse_nfe(xml_bytes):
    try:
        root = ET.fromstring(xml_bytes)
    except ET.ParseError as exc:
        raise ValueError(f"XML inválido: {exc}") from exc

    # Encontra infNFe independentemente do namespace ou de estar sob nfeProc.
    inf_nfe = next((el for el in root.iter() if local_name(el.tag) == "infNFe"), None)
    if inf_nfe is None:
        raise ValueError("Não foi encontrado o elemento infNFe. Verifique se é um XML de NF-e.")

    ide = next((el for el in inf_nfe if local_name(el.tag) == "ide"), None)
    numero_nf = child_text(ide, "nNF", "Não informado") if ide is not None else "Não informado"

    data_emissao = child_text(ide, "dhEmi", "") or child_text(ide, "dEmi", "")

    destinatario = next((el for el in inf_nfe if local_name(el.tag) == "dest"), None)
    razao_social = child_text(destinatario, "xNome", "") if destinatario is not None else ""
    endereco_destinatario = next((el for el in destinatario if local_name(el.tag) == "enderDest"), None) if destinatario is not None else None
    uf = child_text(endereco_destinatario, "UF", "") if endereco_destinatario is not None else ""

    # Dados adicionais da NF-e: infAdic/infCpl.
    inf_adic = next((el for el in inf_nfe if local_name(el.tag) == "infAdic"), None)
    dados_adicionais = child_text(inf_adic, "infCpl", "") if inf_adic is not None else ""

    produtos = []
    for det in inf_nfe:
        if local_name(det.tag) != "det":
            continue
        prod = next((el for el in det if local_name(el.tag) == "prod"), None)
        if prod is None:
            continue

        nome = child_text(prod, "xProd", "").strip()
        if not nome:
            nome = "Produto sem descrição"

        valor_unitario_txt = child_text(prod, "vUnCom", "")
        valor_total_txt = child_text(prod, "vProd", "")
        if not valor_unitario_txt or not valor_total_txt:
            raise ValueError(f"Produto {nome!r}: XML sem vUnCom ou vProd.")

        produtos.append({
            "nome_produto": nome,
            "cfop": child_text(prod, "CFOP", ""),
            "quantidade": float(to_decimal(child_text(prod, "qCom", "0"), "qCom")),
            "valor_unitario": float(to_decimal(valor_unitario_txt, "vUnCom")),
            "valor_total_produto": float(to_decimal(valor_total_txt, "vProd")),
        })

    return {"numero_nf": numero_nf, "uf": uf, "data_emissao": data_emissao, "razao_social": razao_social, "dados_adicionais": dados_adicionais, "produtos": produtos}
