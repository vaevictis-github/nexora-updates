"""OCR adaptado de rename.py do projeto pypro enviado pelo usuário."""
import os
import json
import tempfile
import re
import shutil
import subprocess
import sys
from pathlib import Path
from io import BytesIO
from PIL import ImageEnhance, ImageFilter
import pytesseract
from pdf2image import convert_from_bytes



# Configuração persistente por usuário, fora da pasta do projeto.
CONFIG_ROOT = Path(os.environ.get("LOCALAPPDATA") or (Path.home() / ".config"))
CONFIG_DIR = CONFIG_ROOT / "Nexora"
CONFIG_FILE = CONFIG_DIR / "ocr_settings.json"
LEGACY_CONFIG_FILE = CONFIG_ROOT / "Xanalyzer" / "ocr_settings.json"
RESOURCE_ROOT = Path(getattr(sys, "_MEIPASS", os.environ.get("NEXORA_RESOURCE_ROOT") or Path(__file__).resolve().parents[1]))


def bundled_paths():
    if os.name != "nt":
        return "", ""
    tess = RESOURCE_ROOT / "tesseract" / "tesseract.exe"
    poppler = RESOURCE_ROOT / "poppler-25.07.0" / "Library" / "bin"
    if tess.is_file() and (tess.parent / "tessdata").is_dir():
        os.environ.setdefault("TESSDATA_PREFIX", str(tess.parent / "tessdata"))
    return str(tess) if tess.is_file() else "", str(poppler) if (poppler / "pdfinfo.exe").is_file() and os.name == "nt" else ""


def load_ocr_settings():
    try:
        # Mantém os caminhos salvos na versão anterior até o primeiro salvamento.
        source = CONFIG_FILE if CONFIG_FILE.is_file() else LEGACY_CONFIG_FILE
        data = json.loads(source.read_text(encoding="utf-8"))
        return {key: str(data.get(key, "")) for key in ("tesseract_path", "poppler_path")}
    except (OSError, ValueError, TypeError):
        return {"tesseract_path": "", "poppler_path": ""}


def save_ocr_settings(tesseract_path, poppler_path):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    data = {"tesseract_path": tesseract_path.strip(), "poppler_path": poppler_path.strip()}
    fd, temp_name = tempfile.mkstemp(prefix="ocr_", suffix=".tmp", dir=CONFIG_DIR)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(data, handle, ensure_ascii=False, indent=2)
        os.replace(temp_name, CONFIG_FILE)
    finally:
        if os.path.exists(temp_name):
            os.unlink(temp_name)
    return data


def configured_paths():
    saved = load_ocr_settings()
    tess, poppler = bundled_paths()
    return {
        "tesseract_path": tess or saved["tesseract_path"] or os.environ.get("TESSERACT_PATH", ""),
        "poppler_path": poppler or saved["poppler_path"] or os.environ.get("POPPLER_PATH", ""),
    }


def render_preview(data):
    images = convert_from_bytes(data, dpi=150, first_page=1, last_page=1,
                                poppler_path=configured_paths()["poppler_path"] or None)
    output = BytesIO()
    images[0].save(output, format="PNG")
    images[0].close()
    output.seek(0)
    return output


def resolve_executables():
    """Detecta Tesseract/Poppler via PATH, variáveis ou caminhos Windows comuns."""
    settings = configured_paths()
    tess_candidates = [settings["tesseract_path"], shutil.which("tesseract"),
        r"C:\Program Files\Tesseract-OCR\tesseract.exe", r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe"]
    tesseract = next((str(p) for p in tess_candidates if p and Path(p).is_file()), None)
    poppler_env = settings["poppler_path"]
    poppler_candidates = [poppler_env, shutil.which("pdfinfo"),
        r"C:\poppler\Library\bin", r"C:\Program Files\poppler\Library\bin"]
    poppler_dir = None
    for candidate in poppler_candidates:
        if not candidate:
            continue
        path = Path(candidate)
        if path.is_file() and path.name.lower().startswith("pdfinfo"):
            path = path.parent
        if (path / ("pdfinfo.exe" if os.name == "nt" else "pdfinfo")).is_file() and (path / ("pdftoppm.exe" if os.name == "nt" else "pdftoppm")).is_file():
            poppler_dir = str(path)
            break
    items = []
    for name, executable, arg in (("Tesseract", tesseract, ["--version"]),
        ("Poppler", str(Path(poppler_dir) / ("pdfinfo.exe" if os.name == "nt" else "pdfinfo")) if poppler_dir else None, ["-v"])):
        ok, message = False, "Executável não localizado"
        if executable:
            try:
                flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
                check = subprocess.run([executable, *arg], capture_output=True, text=True, timeout=8, creationflags=flags)
                ok = check.returncode == 0
                message = executable if ok else f"Falha ao executar: {executable}"
            except (OSError, subprocess.TimeoutExpired) as exc:
                message = str(exc)
        items.append({"nome": name, "ok": ok, "mensagem": message})
    if tesseract:
        pytesseract.pytesseract.tesseract_cmd = tesseract
    if poppler_dir:
        os.environ["POPPLER_PATH"] = poppler_dir
    return {"ok": all(i["ok"] for i in items), "itens": items}

def extract_invoice_number(data):
    settings = configured_paths()
    tesseract = settings["tesseract_path"]
    if tesseract:
        pytesseract.pytesseract.tesseract_cmd = tesseract
    poppler = settings["poppler_path"] or None
    images = convert_from_bytes(data, dpi=400, first_page=1, last_page=1, poppler_path=poppler)
    if not images:
        raise ValueError("PDF sem páginas renderizáveis")
    base = images[0].convert("L")
    w, h = base.size
    # Região original: últimos 800 pixels à direita, 300 pixels de altura a 400 DPI.
    roi = base.crop((max(0, w - 800), 0, w, min(h, 300)))
    # Preserva a matriz de pré-processamento original, mas evita salvar dezenas de imagens por PDF.
    for th in (120, 140, 160, 180):
        for contrast in (1.5, 2, 2.5):
            img = ImageEnhance.Contrast(roi.filter(ImageFilter.MedianFilter())).enhance(contrast)
            img = img.point(lambda x: 0 if x < th else 255, "1")
            for psm in (6, 7, 8):
                text = pytesseract.image_to_string(img, lang=os.environ.get("OCR_LANG", "por+eng"),
                    config=f"--oem 3 --psm {psm} -c tessedit_char_whitelist=0123456789NFº")
                # O script original reconhecia números com 8 ou 9 dígitos e zeros iniciais.
                # Aceita também 1–9 dígitos para notas que não usam preenchimento com zeros.
                for match in re.finditer(r"N[º°oO0Ff]?\D*(\d{1,9})(?!\d)", text, re.I):
                    number = match.group(1).lstrip("0") or "0"
                    if number != "0":
                        return number
    return None
