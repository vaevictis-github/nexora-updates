// Mantém as ferramentas no mesmo documento e preserva seus estados e arquivos.
(() => {
  const views = new Map(Array.from(document.querySelectorAll('.app-view'), view => [view.id.slice(5), view]));
  const navItems = document.querySelectorAll('.main-nav [data-view]');
  function showView(name, target) {
    if (!views.has(name)) return;
    for (const [key, view] of views) view.hidden = key !== name;
    for (const button of navItems) {
      if (button.dataset.view === name && button.dataset.target === target) {
        button.setAttribute('aria-current', 'page');
        document.getElementById('current-view').textContent = button.textContent.trim();
      } else button.removeAttribute('aria-current');
    }
    window.scrollTo(0, 0);
    if (target) {
      const section = document.getElementById(target);
      if (section instanceof HTMLDetailsElement) section.open = true;
      section?.scrollIntoView({block: 'start'});
    }
  }
  document.querySelectorAll('[data-view]').forEach(button => {
    button.addEventListener('click', () => showView(button.dataset.view, button.dataset.target));
  });
  showView('home');
})();
