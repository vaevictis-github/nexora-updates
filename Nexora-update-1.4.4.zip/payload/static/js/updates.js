(() => {
  const $ = id => document.getElementById(`update-${id}`);
  let busy = false, prepared = false, available = false, rollback = false;
  const controls = ['save', 'check', 'download', 'manual', 'install', 'rollback'];
  function render() {
    controls.forEach(id => $(id).disabled = busy || !window.pywebview?.api || (id === 'download' && !available) || (id === 'install' && !prepared) || (id === 'rollback' && !rollback));
  }
  function status(message) { $('status').textContent = message; }
  async function task(fn) {
    if (busy) return;
    busy = true; render();
    try { await fn(); } catch (error) { status(error.message || String(error)); }
    finally { busy = false; render(); }
  }
  function checkError(result) { if (result.error) throw Error(result.error); return result; }
  function showPackage(result) {
    checkError(result);
    if (result.cancelled) { status('Seleção cancelada.'); return; }
    const p = result.package;
    prepared = true;
    status(`Versão ${p.version} validada: ${p.changed} arquivo(s) no pacote. Pronta para instalação.`);
    $('details').textContent = p.notes;
  }
  async function init() {
    await task(async () => {
      const s = checkError(await window.pywebview.api.status());
      $('version').textContent = s.version; $('repo').value = s.repo; rollback = s.rollback;
      $('notice').textContent = s.notice;
      if (s.notice) alert(s.notice);
    });
    if ($('repo').value) $('check').click();
  }
  $('save').onclick = () => task(async () => { available = false; $('badge').hidden = true; checkError(await window.pywebview.api.configure($('repo').value)); status('Origem salva.'); $('online-info').textContent = ''; });
  $('check').onclick = () => task(async () => {
    available = false; $('badge').hidden = true; status('Consultando GitHub Releases...');
    const result = checkError(await window.pywebview.api.check());
    available = Boolean(result.available);
    $('badge').hidden = !available;
    $('online-info').textContent = available ? `Disponível: ${result.available.version} (${result.available.incremental ? 'incremental' : 'completo'}). ${result.available.notes}` : 'Você já possui a versão mais recente.';
    status(available ? 'Clique em Baixar e validar para preparar a atualização.' : 'Nenhuma atualização necessária.');
  });
  $('download').onclick = () => task(async () => { prepared = false; $('details').textContent = ''; status('Baixando e validando...'); showPackage(await window.pywebview.api.prepare_online()); });
  $('manual').onclick = () => task(async () => { prepared = false; $('details').textContent = ''; status('Selecione um pacote...'); showPackage(await window.pywebview.api.prepare_manual()); });
  function restart(restore) {
    if (!document.getElementById('busy-overlay').hidden) {
      status('Aguarde o término do processamento de documentos antes de reiniciar.'); return;
    }
    if (!confirm(`${restore ? 'Restaurar a versão anterior' : 'Instalar a atualização'} e reiniciar o Nexora? Salve os resultados da sessão antes de continuar.`)) return;
    task(async () => { status('Reiniciando...'); checkError(await window.pywebview.api.restart(restore)); });
  }
  $('install').onclick = () => restart(false);
  $('rollback').onclick = () => restart(true);
  render();
  if (window.pywebview?.api) init(); else window.addEventListener('pywebviewready', init, {once:true});
})();
