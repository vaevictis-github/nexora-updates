"""Índice de NF-e para organizar PDFs a partir de XMLs, ZIPs e 7z.

Reutiliza o mesmo leitor limitado/validado da tela Importar XML.
"""

from processor.archive_reader import ArchiveError, iter_xml_documents
from processor.xml_reader import parse_nfe


def indexar_referencias(arquivos, normalizar_numero):
    """Retorna (índice por número, erros, quantidade de NF-es válidas).

    Um arquivo compactado pode conter XMLs em subpastas e XMLs inválidos.
    Os erros são registrados individualmente sem descartar os documentos válidos.
    """
    indice = {}
    erros = []
    validas = 0
    for arquivo in arquivos:
        if not arquivo.filename:
            continue
        try:
            for nome, conteudo in iter_xml_documents(arquivo):
                try:
                    nota = parse_nfe(conteudo)
                    numero = normalizar_numero(nota["numero_nf"])
                    if not numero:
                        raise ValueError("Número da NF-e ausente ou inválido")
                    razao_social = nota["razao_social"].strip()
                    if not razao_social:
                        raise ValueError("Razão social do destinatário ausente")
                    indice.setdefault(numero, set()).add(razao_social)
                    validas += 1
                except (ValueError, KeyError, TypeError) as exc:
                    erros.append(f"{nome}: {exc}")
        except (ArchiveError, ValueError, OSError, RuntimeError) as exc:
            erros.append(f"{arquivo.filename}: {exc}")
    return indice, erros, validas
