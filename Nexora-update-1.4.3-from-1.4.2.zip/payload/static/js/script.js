const fileInput = document.getElementById("files");
const dropzone = document.getElementById("dropzone");
const analyzeButton = document.getElementById("analyze");
const exportButton = document.getElementById("export");
const exportSelectedButton = document.getElementById("export-selected");
const selectAllNotas = document.getElementById("select-all-notas");
const selectedNotaIndices = new Set();
const fileCount = document.getElementById("file-count");
const resultsBody = document.getElementById("results");
const errorsBox = document.getElementById("errors");
const filterNf = document.getElementById("filter-nf");
const filterProduct = document.getElementById("filter-product");
const filterAdditional = document.getElementById("filter-additional");
const filterCfop = document.getElementById("filter-cfop");
const filterClient = document.getElementById("filter-client");
const filterStatus = document.getElementById("filter-status");
const clearFiltersButton = document.getElementById("clear-filters");
const applyFiltersButton = document.getElementById("apply-filters");
const filterSummary = document.getElementById("filter-summary");
const filterInputs = [filterNf, filterProduct, filterCfop, filterClient, filterStatus, filterAdditional];
const productToggle = document.getElementById("product-toggle");
const productOptions = document.getElementById("product-options");
const productOptionsList = document.getElementById("product-options-list");
const selectedProductsBox = document.getElementById("selected-products");
let selectedProducts = new Map();
let availableProducts = [];
// Os campos representam um rascunho. A tabela usa somente os filtros aplicados.
let appliedFilters = { nf: "", products: [], additional: "", cfop: "", client: "", status: "" };
function captureFilters() {
  return {
    nf: normalizeText(filterNf.value),
    products: [...selectedProducts.keys(), ...filterProduct.value.split(";").map(normalizeText).filter(Boolean)],
    additional: normalizeText(filterAdditional.value),
    cfop: normalizeText(filterCfop.value),
    client: normalizeText(filterClient.value),
    status: filterStatus.value
  };
}
function hasPendingFilters() {
  return JSON.stringify(captureFilters()) !== JSON.stringify(appliedFilters);
}
function updateApplyButton() {
  applyFiltersButton.disabled = currentNotas.length === 0;
  // Não atualiza linhas até o usuário aplicar a pesquisa.
  applyFiltersButton.classList.toggle("filter-pending", currentNotas.length > 0 && hasPendingFilters());
}


const busyOverlay = document.getElementById("busy-overlay");
const busyTitle = document.getElementById("busy-title");
const busySubtitle = document.getElementById("busy-subtitle");
let busyOperations = 0;
function startBusy(title, subtitle = "Aguarde a conclusão da operação.") {
  busyOperations++;
  busyTitle.textContent = title;
  busySubtitle.textContent = subtitle;
  busyOverlay.hidden = false;
}
function stopBusy() {
  busyOperations = Math.max(0, busyOperations - 1);
  if (!busyOperations) busyOverlay.hidden = true;
}
let selectedFiles = [];
let currentNotas = [];  // Grouped by source XML for the expandable screen.
const PAGE_SIZE = 100;
let currentPage = 1;
let filteredIndices = [];
const pagePrev = document.getElementById("page-prev");
const pageNext = document.getElementById("page-next");
const pageStatus = document.getElementById("page-status");
function refreshFilteredIndices() {
  filteredIndices = [];
  for (let i = 0; i < currentNotas.length; i++) {
    if (matchesNota(currentNotas[i])) filteredIndices.push(i);
  }
  currentPage = 1;
}
function pageIndices() {
  return filteredIndices.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);
}
function updatePagination() {
  const totalPages = Math.max(1, Math.ceil(filteredIndices.length / PAGE_SIZE));
  currentPage = Math.max(1, Math.min(currentPage, totalPages));
  pageStatus.textContent = `${currentPage} / ${totalPages}`;
  pagePrev.disabled = currentPage <= 1;
  pageNext.disabled = currentPage >= totalPages;
}
pagePrev.addEventListener("click", () => { currentPage--; renderRows(); });
pageNext.addEventListener("click", () => { currentPage++; renderRows(); });

function setFiles(files) {
  selectedFiles = Array.from(files).filter(file => /\.(xml|zip|7z)$/i.test(file.name));
  fileCount.textContent = selectedFiles.length
    ? `${selectedFiles.length} arquivo(s) XML/ZIP/7z selecionado(s)`
    : "Nenhum XML, ZIP ou 7z válido selecionado";
  analyzeButton.disabled = selectedFiles.length === 0;
}

fileInput.addEventListener("change", () => setFiles(fileInput.files));

["dragenter", "dragover"].forEach(evt => dropzone.addEventListener(evt, e => {
  e.preventDefault();
  dropzone.classList.add("dragover");
}));
["dragleave", "drop"].forEach(evt => dropzone.addEventListener(evt, e => {
  e.preventDefault();
  dropzone.classList.remove("dragover");
}));
dropzone.addEventListener("drop", e => setFiles(e.dataTransfer.files));

function money(value) {
  return Number(value).toLocaleString("pt-BR", {
    style: "currency", currency: "BRL"
  });
}

function safeText(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[char]));
}

analyzeButton.addEventListener("click", async () => {
  if (!selectedFiles.length) return;

  analyzeButton.disabled = true;
  analyzeButton.textContent = "Analisando...";
  errorsBox.hidden = true;
  errorsBox.textContent = "";
  startBusy("Analisando documentos fiscais", "Lendo XMLs e arquivos ZIP/7z. Isso pode levar alguns instantes.");

  const form = new FormData();
  selectedFiles.forEach(file => form.append("arquivos", file));

  try {
    const response = await fetch("/api/analisar", { method: "POST", body: form });
    const data = await response.json();
    if (!response.ok) throw new Error(data.erro || "Falha ao analisar os arquivos.");

    currentNotas = data.notas || [];
    selectedNotaIndices.clear();
    filterInputs.forEach(input => { input.disabled = currentNotas.length === 0; });
    clearFiltersButton.disabled = currentNotas.length === 0;
    appliedFilters = { nf: "", products: [], additional: "", cfop: "", client: "", status: "" };
    productToggle.disabled = currentNotas.length === 0;
    selectedProducts.clear();
    filterInputs.forEach(input => { input.value = ""; });
    productOptions.hidden = true;
    productToggle.setAttribute("aria-expanded", "false");
    buildProductOptions();
    updateApplyButton();

    document.getElementById("notes-count").textContent = data.notas_lidas || 0;
    document.getElementById("canceled-count").textContent = data.notas_canceladas || 0;
    const unmatched = Number(data.eventos_sem_nota || 0);
    if (unmatched) {
      errorsBox.hidden = false;
      errorsBox.textContent = `${unmatched} evento(s) de cancelamento confirmado(s) sem XML de NF-e correspondente na importação.`;
    }

    refreshFilteredIndices();
    renderRows();
    exportButton.disabled = currentNotas.length === 0;
    updateSelectionControls();
    document.getElementById("import-feedback-title").textContent = "Importação concluída";
    document.getElementById("import-feedback-details").textContent = `${data.notas_lidas || 0} nota(s) processada(s); ${data.notas_canceladas || 0} cancelamento(s) identificado(s). Os relatórios estão disponíveis no menu lateral.`;

    if (data.erros && data.erros.length) {
      errorsBox.hidden = false;
      const eventNote = errorsBox.hidden ? "" : `<div>${safeText(errorsBox.textContent)}</div>`;
      errorsBox.innerHTML = eventNote + "<strong>Arquivos não processados:</strong><br>" +
        data.erros.map(item =>
          `${safeText(item.arquivo)}: ${safeText(item.erro)}`
        ).join("<br>");
    }
    window.nexoraNavigate?.("report");
  } catch (error) {
    document.getElementById("import-feedback-title").textContent = "Falha na importação";
    document.getElementById("import-feedback-details").textContent = error.message;
    errorsBox.hidden = false;
    errorsBox.textContent = error.message;
  } finally {
    stopBusy();
    analyzeButton.disabled = selectedFiles.length === 0;
    analyzeButton.textContent = "Importar e analisar";
  }
});

function normalizeText(value) {
  return String(value ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .toLocaleLowerCase("pt-BR").trim();
}

function matchesNota(nota) {
  const { nf, products, additional, cfop, client, status } = appliedFilters;
  if (status && nota.situacao_nf !== status) return false;
  if (nf && !normalizeText(nota.numero_nf).includes(nf)) return false;
  if (additional && !normalizeText(nota.dados_adicionais).includes(additional)) return false;
  if (client && !normalizeText(nota.razao_social).includes(client)) return false;
  if (cfop && !(nota.cfops || []).some(c => normalizeText(c).includes(cfop))) return false;
  if (products.length && !(nota.produtos || []).some(product => {
    const name = normalizeText(product.nome_produto);
    return products.some(term => name.includes(term));
  })) return false;
  return true;
}
function updateSelectionControls() {
  let checked = 0;
  for (const index of filteredIndices) if (selectedNotaIndices.has(index)) checked++;
  selectAllNotas.disabled = filteredIndices.length === 0;
  selectAllNotas.checked = filteredIndices.length > 0 && checked === filteredIndices.length;
  selectAllNotas.indeterminate = checked > 0 && checked < filteredIndices.length;
  exportSelectedButton.disabled = selectedNotaIndices.size === 0;
  exportSelectedButton.textContent = `Exportar selecionados (${selectedNotaIndices.size})`;
}

selectAllNotas.addEventListener("change", () => {
  for (const index of filteredIndices) {
    if (selectAllNotas.checked) selectedNotaIndices.add(index);
    else selectedNotaIndices.delete(index);
  }
  renderRows();
});

function formatEmissionDate(value) {
  if (!value) return "—";
  const match = String(value).match(/^(\d{4})-(\d{2})-(\d{2})/);
  return match ? `${match[3]}/${match[2]}/${match[1]}` : String(value);
}

function renderRows() {
  updatePagination();
  updateSelectionControls();
  if (!currentNotas.length) {
    resultsBody.innerHTML = '<tr><td colspan="7" class="empty">Nenhuma nota fiscal foi identificada.</td></tr>';
    filterSummary.textContent = "Nenhuma nota carregada.";
    return;
  }
  filterSummary.textContent = `Exibindo ${filteredIndices.length} de ${currentNotas.length} nota(s). Mostrando até ${PAGE_SIZE} por página.`;
  if (!filteredIndices.length) {
    resultsBody.innerHTML = '<tr><td colspan="7" class="empty">Nenhuma nota corresponde aos filtros informados.</td></tr>';
    return;
  }
  // Renderiza só uma página e não cria tabelas de produtos recolhidas.
  resultsBody.innerHTML = pageIndices().map(notaIndex => {
    const nota = currentNotas[notaIndex];
    const detailsId = `products-${notaIndex}`;
    const additional = nota.dados_adicionais ? safeText(nota.dados_adicionais) : '<span class="muted">—</span>';
    const canceled = nota.situacao_nf === "Cancelada";
    const cancelDate = canceled ? formatEmissionDate(nota.data_cancelamento) : "";
    const statusLabel = canceled ? `<span class="invoice-status canceled">Cancelada</span><span class="cancel-date">${safeText(cancelDate)}</span>` : `<span class="invoice-status unverified">Não verificada</span>`;
    return `
      <tr class="invoice-row"><td><div class="invoice-selector"><input type="checkbox" class="nota-checkbox" data-nota-index="${notaIndex}" aria-label="Selecionar NF ${safeText(nota.numero_nf)}" ${selectedNotaIndices.has(notaIndex) ? "checked" : ""}><button class="expand-button" type="button" aria-expanded="false" aria-controls="${detailsId}" data-nota-index="${notaIndex}"><span class="chevron" aria-hidden="true">›</span><strong>${safeText(nota.numero_nf)}</strong></button></div></td>
      <td>${safeText(nota.uf || "—")}</td><td>${safeText(nota.razao_social || "—")}</td><td>${safeText((nota.cfops || []).join(", ") || "—")}</td><td>${safeText(formatEmissionDate(nota.data_emissao))}</td>
      <td>${statusLabel}</td><td class="additional-cell">${additional}</td></tr>
      <tr class="details-row" id="${detailsId}" hidden><td colspan="7"></td></tr>`;
  }).join("");
}
// Delegação: nenhum listener individual por linha ou produto renderizado.
resultsBody.addEventListener("change", event => {
  const box = event.target.closest(".nota-checkbox");
  if (!box) return;
  const index = Number(box.dataset.notaIndex);
  if (box.checked) selectedNotaIndices.add(index);
  else selectedNotaIndices.delete(index);
  updateSelectionControls();
});
resultsBody.addEventListener("click", event => {
  const button = event.target.closest(".expand-button");
  if (!button) return;
  const index = Number(button.dataset.notaIndex);
  const detailRow = document.getElementById(`products-${index}`);
  const expanding = button.getAttribute("aria-expanded") !== "true";
  button.setAttribute("aria-expanded", String(expanding));
  detailRow.hidden = !expanding;
  if (!expanding || detailRow.dataset.loaded) return;
  const nota = currentNotas[index];
  const products = nota.produtos || [];
  detailRow.firstElementChild.innerHTML = `<div class="details-panel"><div class="details-title">Produtos da NF ${safeText(nota.numero_nf)}</div>
    <div class="table-wrap nested-wrap"><table class="nested-table"><thead><tr><th>Nome do Produto</th><th>CFOP</th><th class="numeric">Quantidade</th><th class="numeric">Valor Unitário</th><th class="numeric">Valor total do Produto</th></tr></thead><tbody>
    ${products.map(product => `<tr><td>${safeText(product.nome_produto)}</td><td>${safeText(product.cfop || "—")}</td><td class="numeric">${quantity(product.quantidade)}</td><td class="numeric">${money(product.valor_unitario)}</td><td class="numeric">${money(product.valor_total_produto)}</td></tr>`).join("")}
    </tbody></table></div><div class="invoice-total"><strong>TOTAL DA NF</strong><strong>${money(nota.valor_total_nf)}</strong></div></div>`;
  detailRow.dataset.loaded = "true";
});

filterInputs.forEach(input => {
  input.addEventListener("input", updateApplyButton);
  input.addEventListener("change", updateApplyButton);
  input.addEventListener("keydown", event => {
    if (event.key === "Enter") {
      event.preventDefault();
      applyFiltersButton.click();
    }
  });
});
applyFiltersButton.addEventListener("click", () => {
  if (!currentNotas.length) return;
  appliedFilters = captureFilters();
  productOptions.hidden = true;
  productToggle.setAttribute("aria-expanded", "false");
  refreshFilteredIndices();
  renderRows();
  updateApplyButton();
});
clearFiltersButton.addEventListener("click", () => {
  filterInputs.forEach(input => { input.value = ""; });
  selectedProducts.clear();
  updateProductSelections();
  appliedFilters = { nf: "", products: [], additional: "", cfop: "", client: "", status: "" };
  refreshFilteredIndices();
  renderRows();
  updateApplyButton();
});
function getSelectedExportRows() {
  return currentNotas.filter((nota, index) => selectedNotaIndices.has(index));
}

async function downloadCsv(rows, filename, button) {
  if (!rows.length) return;
  button.disabled = true;
  startBusy("Gerando CSV");
  try {
    const response = await fetch("/api/exportar", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        notas: rows.map(({ numero_nf, uf, razao_social, data_emissao, dados_adicionais, situacao_nf, data_cancelamento, protocolo_cancelamento, produtos }) => ({
          numero_nf, uf, razao_social, data_emissao, dados_adicionais, situacao_nf, data_cancelamento, protocolo_cancelamento,
          produtos: (produtos || []).map(({ nome_produto, cfop, valor_unitario, quantidade }) => ({
            nome_produto, cfop, valor_unitario, quantidade
          }))
        }))
      })
    });
    if (!response.ok) throw new Error("Não foi possível gerar o CSV.");

    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  } catch (error) {
    errorsBox.hidden = false;
    errorsBox.textContent = error.message;
  } finally {
    stopBusy();
    if (button === exportButton) exportButton.disabled = currentNotas.length === 0;
    else updateSelectionControls();
  }
}

exportButton.addEventListener("click", () => downloadCsv(currentNotas, "analise_nfe.csv", exportButton));
exportSelectedButton.addEventListener("click", () => downloadCsv(getSelectedExportRows(), "analise_nfe_selecionadas.csv", exportSelectedButton));

function quantity(value) {
  return Number(value).toLocaleString("pt-BR", {maximumFractionDigits: 10});
}

function buildProductOptions() {
  const unique = new Map();
  currentNotas.forEach(nota => (nota.produtos || []).forEach(product => {
    const name = String(product.nome_produto || "");
    const key = normalizeText(name);
    if (key && !unique.has(key)) unique.set(key, name);
  }));
  availableProducts = [...unique].sort((a, b) => a[1].localeCompare(b[1], "pt-BR"));
  productOptionsList.innerHTML = availableProducts.length ? availableProducts.map(([key, name], i) =>
    `<label class="product-option"><input type="checkbox" data-product-index="${i}"><span>${safeText(name)}</span></label>`
  ).join("") : '<p class="muted">Nenhum produto disponível.</p>';
  productOptionsList.querySelectorAll('input[type="checkbox"]').forEach(box => {
    box.addEventListener("change", () => {
      const [key, name] = availableProducts[Number(box.dataset.productIndex)];
      if (box.checked) selectedProducts.set(key, name);
      else selectedProducts.delete(key);
      updateProductSelections();
      updateApplyButton();
    });
  });
  updateProductSelections();
}

function updateProductSelections() {
  productOptionsList.querySelectorAll('input[type="checkbox"]').forEach(box => {
    box.checked = selectedProducts.has(availableProducts[Number(box.dataset.productIndex)][0]);
  });
  selectedProductsBox.innerHTML = [...selectedProducts].map(([key, name]) =>
    `<span class="product-chip">${safeText(name)} <button type="button" data-remove-key="${safeText(key)}" aria-label="Remover ${safeText(name)}">×</button></span>`
  ).join("");
  selectedProductsBox.querySelectorAll("button[data-remove-key]").forEach(button => {
    button.addEventListener("click", () => {
      selectedProducts.delete(button.dataset.removeKey);
      updateProductSelections();
      updateApplyButton();
    });
  });
}

productToggle.addEventListener("click", () => {
  productOptions.hidden = !productOptions.hidden;
  productToggle.setAttribute("aria-expanded", String(!productOptions.hidden));
});
document.addEventListener("click", event => {
  if (!event.target.closest(".product-filter")) {
    productOptions.hidden = true;
    productToggle.setAttribute("aria-expanded", "false");
  }
});


// Organização independente da análise da tabela.
const organizeXmlInput = document.getElementById("organize-xmls");
const organizePdfInput = document.getElementById("organize-pdfs");
const organizeButton = document.getElementById("organize-button");
const organizeStatus = document.getElementById("organize-status");
function updateOrganizeInputs() {
  const x = organizeXmlInput.files.length;
  const p = organizePdfInput.files.length;
  document.getElementById("organize-xml-count").textContent = x ? `${x} arquivo(s) XML/ZIP/7z selecionado(s)` : "Selecione XMLs ou ZIP/7z";
  document.getElementById("organize-pdf-count").textContent = `${p} PDF(s) selecionado(s)`;
  organizeButton.disabled = !x || (!p && !(document.getElementById("organize-use-ocr").checked && ocrRecords.some(r => r.filename)));
}
organizeXmlInput.addEventListener("change", updateOrganizeInputs);
organizePdfInput.addEventListener("change", updateOrganizeInputs);
organizeButton.addEventListener("click", async () => {
  if (organizeButton.disabled) return;
  organizeButton.disabled = true;
  organizeStatus.textContent = "Organizando arquivos...";
  startBusy("Organizando PDFs", "Preparando pastas por razão social e gerando o ZIP.");
  try {
    const data = new FormData();
    for (const file of organizeXmlInput.files) data.append("xmls", file);
    if (document.getElementById("organize-use-ocr").checked) data.append("origem", "ocr");
    else for (const file of organizePdfInput.files) data.append("pdfs", file);
    const response = await fetch("/api/organizar-pdfs", { method: "POST", body: data });
    if (!response.ok) {
      const detail = await response.json().catch(() => ({}));
      throw new Error(detail.erro || `Erro HTTP ${response.status}`);
    }
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "pdfs_por_razao_social.zip";
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
    organizeStatus.textContent = "ZIP gerado. Confira relatorio_organizacao.json para verificar PDFs não identificados, ambíguos ou XMLs inválidos.";
  } catch (error) {
    organizeStatus.textContent = `Falha: ${error.message}`;
  } finally {
    stopBusy();
    updateOrganizeInputs();
  }
});

// OCR: arquivos mantidos no servidor Flask na sessão atual.
const ocrInput = document.getElementById("ocr-pdfs");
const ocrButton = document.getElementById("ocr-button");
const ocrDownload = document.getElementById("ocr-download");
const ocrStatus = document.getElementById("ocr-status");
const ocrList = document.getElementById("ocr-records");
const ocrViewer = document.getElementById("ocr-viewer");
let ocrRecords = [];
let selectedOcrId = null;

ocrInput.addEventListener("change", () => {
  document.getElementById("ocr-pdf-count").textContent = `${ocrInput.files.length} PDF(s) selecionado(s)`;
  updateOcrButton();
});
document.getElementById("organize-use-ocr").addEventListener("change", () => {
  const using = document.getElementById("organize-use-ocr").checked;
  organizePdfInput.disabled = using;
  updateOrganizeInputs();
});
// Seleção única: o visualizador usa 100% da largura, e a lista é um painel flutuante.
const ocrPrev = document.getElementById("ocr-prev");
const ocrNext = document.getElementById("ocr-next");
const ocrPosition = document.getElementById("ocr-position");
const ocrCurrentTitle = document.getElementById("ocr-current-title");
const ocrCurrentStatus = document.getElementById("ocr-current-status");
const ocrEdit = document.getElementById("ocr-current-edit");
const ocrNumber = document.getElementById("ocr-number");
const ocrSave = document.getElementById("ocr-save");
const ocrEditStatus = document.getElementById("ocr-edit-status");
const ocrListToggle = document.getElementById("ocr-list-toggle");
const ocrListPanel = document.getElementById("ocr-list-panel");
const ocrListBackdrop = document.getElementById("ocr-list-backdrop");
const ocrListClose = document.getElementById("ocr-list-close");
const ocrPreviewHint = document.getElementById("ocr-preview-hint");
function closeOcrList() {
  ocrListPanel.hidden = true;
  ocrListBackdrop.hidden = true;
  ocrListToggle.setAttribute("aria-expanded", "false");
  ocrListToggle.focus();
}
function openOcrList() {
  if (!ocrRecords.length) return;
  ocrListPanel.hidden = false;
  ocrListBackdrop.hidden = false;
  ocrListToggle.setAttribute("aria-expanded", "true");
  ocrListClose.focus();
  ocrList.querySelector(".active")?.scrollIntoView({block:"nearest"});
}
ocrListToggle.addEventListener("click", () => ocrListPanel.hidden ? openOcrList() : closeOcrList());
ocrListClose.addEventListener("click", closeOcrList);
ocrListBackdrop.addEventListener("click", closeOcrList);
document.addEventListener("keydown", event => {
  if (event.key === "Escape" && !ocrListPanel.hidden) { event.preventDefault(); closeOcrList(); }
  if (document.getElementById("view-ocr").hidden || !ocrListPanel.hidden) return;
  if (["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement?.tagName)) return;
  if (event.altKey || event.ctrlKey || event.metaKey) return;
  if (event.key === "ArrowLeft" && !ocrPrev.disabled) { event.preventDefault(); ocrPrev.click(); }
  if (event.key === "ArrowRight" && !ocrNext.disabled) { event.preventDefault(); ocrNext.click(); }
});
function selectOcrRecord(index, closeList = false) {
  if (index < 0 || index >= ocrRecords.length) return;
  selectedOcrId = ocrRecords[index].id;
  showOcrRecords();
  if (closeList && !ocrListPanel.hidden) closeOcrList();
}
ocrPrev.addEventListener("click", () => selectOcrRecord(ocrRecords.findIndex(r => r.id === selectedOcrId) - 1));
ocrNext.addEventListener("click", () => selectOcrRecord(ocrRecords.findIndex(r => r.id === selectedOcrId) + 1));
async function saveOcrCorrection() {
  const record = ocrRecords.find(r => r.id === selectedOcrId);
  if (!record) return;
  ocrSave.disabled = true;
  ocrEditStatus.textContent = "Salvando...";
  try {
    const res = await fetch(`/api/ocr/renomear/${encodeURIComponent(record.id)}`, {
      method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({numero_nf: ocrNumber.value.trim()})
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.erro || "Erro ao renomear");
    ocrRecords = ocrRecords.map(r => r.id === record.id ? data.arquivo : r);
    showOcrRecords();
    ocrEditStatus.textContent = "Número corrigido e PDF renomeado.";
    ocrStatus.textContent = "Número corrigido e PDF renomeado na sessão.";
  } catch (error) {
    ocrEditStatus.textContent = `Falha: ${error.message}`;
  } finally { ocrSave.disabled = false; }
}
ocrSave.addEventListener("click", saveOcrCorrection);
ocrNumber.addEventListener("keydown", event => {
  if (event.key === "Enter") { event.preventDefault(); saveOcrCorrection(); }
});
function showOcrRecords() {
  ocrDownload.disabled = !ocrRecords.some(r => r.filename);
  ocrListToggle.disabled = !ocrRecords.length;
  ocrList.replaceChildren();
  if (!ocrRecords.length) {
    selectedOcrId = null;
    ocrList.textContent = "Nenhum PDF processado.";
    ocrViewer.removeAttribute("src");
    ocrCurrentTitle.textContent = "Nenhum PDF processado";
    ocrCurrentStatus.textContent = "";
    ocrPosition.textContent = "0 de 0";
    ocrPrev.disabled = ocrNext.disabled = true;
    ocrEdit.hidden = true;
    ocrPreviewHint.textContent = "Processe os PDFs acima para iniciar a conferência.";
    if (!ocrListPanel.hidden) closeOcrList();
    updateOrganizeInputs();
    return;
  }
  let index = ocrRecords.findIndex(r => r.id === selectedOcrId);
  if (index < 0) index = 0;
  const current = ocrRecords[index];
  const changed = selectedOcrId !== current.id || ocrViewer.dataset.currentId !== current.id;
  selectedOcrId = current.id;
  if (changed) {
    ocrViewer.src = `/api/ocr/pdf/${encodeURIComponent(current.id)}`;
    ocrViewer.dataset.currentId = current.id;
    ocrEditStatus.textContent = "";
  }
  ocrCurrentTitle.textContent = current.filename || current.original || `Nota ${index + 1}`;
  ocrCurrentStatus.textContent = `${current.original || "PDF"} • ${current.status || "pendente"}${current.erro ? " • " + current.erro : ""}`;
  ocrNumber.value = current.numero_nf || "";
  ocrEdit.hidden = false;
  ocrPosition.textContent = `${index + 1} de ${ocrRecords.length}`;
  ocrPrev.disabled = index <= 0;
  ocrNext.disabled = index >= ocrRecords.length - 1;
  ocrPreviewHint.textContent = "Use Anterior/Próxima para conferir as páginas ou Lista de notas para ir diretamente a uma posição.";
  for (let i = 0; i < ocrRecords.length; i++) {
    const record = ocrRecords[i];
    const item = document.createElement("button");
    item.type = "button";
    item.className = "ocr-list-entry" + (record.id === selectedOcrId ? " active" : "");
    item.setAttribute("aria-current", record.id === selectedOcrId ? "true" : "false");
    const number = document.createElement("span");
    number.className = "ocr-list-ordinal";
    number.textContent = String(i + 1).padStart(2, "0");
    const content = document.createElement("span");
    content.className = "ocr-list-entry-content";
    const name = document.createElement("strong");
    name.textContent = record.filename || record.original || "Sem nome";
    const desc = document.createElement("small");
    desc.textContent = `${record.original || ""} • ${record.status || "pendente"}`;
    content.append(name, desc);
    item.append(number, content);
    item.addEventListener("click", () => selectOcrRecord(i, true));
    ocrList.append(item);
  }
  updateOrganizeInputs();
}
const dependencyStatus = document.getElementById("dependency-status");
const dependencyRecheck = document.getElementById("dependency-recheck");
const ocrProgressBox = document.getElementById("ocr-progress-box");
const ocrProgress = document.getElementById("ocr-progress");
const ocrPercent = document.getElementById("ocr-percent");
let dependenciesOk = false;
let ocrBusy = false;
function updateOcrButton() { ocrButton.disabled = ocrBusy || !dependenciesOk || !ocrInput.files.length; }
async function verifyDependencies() {
  dependencyStatus.textContent = "Verificando Tesseract e Poppler...";
  dependencyRecheck.disabled = true;
  try {
    const response = await fetch("/api/dependencias");
    const result = await response.json();
    dependenciesOk = Boolean(result.ok);
    dependencyStatus.textContent = result.itens.map(item => `${item.nome}: ${item.ok ? "OK" : "INDISPONÍVEL"} (${item.mensagem})`).join(" | ");
  } catch(e) { dependenciesOk = false; dependencyStatus.textContent = `Falha na verificação: ${e.message}`; }
  finally { dependencyRecheck.disabled = false; updateOcrButton(); }
}
const ocrTesseractPath = document.getElementById("ocr-tesseract-path");
const ocrPopplerPath = document.getElementById("ocr-poppler-path");
const ocrSettingsSave = document.getElementById("ocr-settings-save");
const ocrSettingsStatus = document.getElementById("ocr-settings-status");
async function loadOcrSettings() {
  try {
    const response = await fetch("/api/ocr/configuracoes");
    if (!response.ok) throw new Error("Não foi possível carregar as configurações");
    const settings = await response.json();
    ocrTesseractPath.value = settings.tesseract_path || "";
    ocrPopplerPath.value = settings.poppler_path || "";
  } catch (error) { ocrSettingsStatus.textContent = error.message; }
}
if (ocrSettingsSave && ocrTesseractPath && ocrPopplerPath && ocrSettingsStatus) {
  ocrSettingsSave.addEventListener("click", async () => {
    ocrSettingsSave.disabled = true;
    ocrSettingsStatus.textContent = "Salvando e verificando...";
    try {
      const response = await fetch("/api/ocr/configuracoes", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({
          tesseract_path: ocrTesseractPath.value.trim(),
          poppler_path: ocrPopplerPath.value.trim()
        })
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.erro || "Erro ao salvar");
      ocrSettingsStatus.textContent = result.dependencias.ok
        ? "Configurações salvas. Dependências disponíveis."
        : "Configurações salvas. Verifique os caminhos indicados no diagnóstico.";
      await verifyDependencies();
    } catch (error) { ocrSettingsStatus.textContent = error.message; }
    finally { ocrSettingsSave.disabled = false; }
  });
} else {
  console.error("Configuração OCR: elementos ausentes no HTML. Confira se index.html e script.js são da mesma versão.");
}

if (ocrTesseractPath && ocrPopplerPath && ocrSettingsStatus) loadOcrSettings();
dependencyRecheck.addEventListener("click", verifyDependencies);
verifyDependencies();
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
ocrButton.addEventListener("click", async () => {
  ocrBusy = true;
  startBusy("Executando OCR", "Acompanhe o percentual de processamento na tela de OCR.");
  updateOcrButton();
  ocrProgressBox.hidden = false;
  ocrProgress.value = 0;
  ocrPercent.textContent = "0%";
  ocrStatus.textContent = "Enviando arquivos para processamento...";
  try {
    const data = new FormData();
    for (const f of ocrInput.files) data.append("pdfs", f);
    const response = await fetch("/api/ocr/processar", {method:"POST",body:data});
    const result = await response.json();
    if (!response.ok) throw new Error(result.erro || "Erro no OCR");
    let progress;
    do {
      await sleep(650);
      const statusResponse = await fetch(`/api/ocr/progresso/${result.job_id}`, {cache:"no-store"});
      progress = await statusResponse.json();
      if (!statusResponse.ok) throw new Error(progress.erro || "Falha ao consultar progresso");
      ocrProgress.value = progress.percentual;
      ocrPercent.textContent = `${progress.percentual}%`;
      ocrStatus.textContent = progress.mensagem;
      busySubtitle.textContent = `${progress.percentual}% — ${progress.mensagem}`;
    } while (!progress.concluido);
    if (progress.erro) throw new Error(progress.erro);
    const recordsResponse = await fetch("/api/ocr/arquivos");
    const records = await recordsResponse.json();
    ocrRecords = records.arquivos || [];
    selectedOcrId = null;
    showOcrRecords();
    ocrStatus.textContent = `${progress.mensagem} ${ocrRecords.filter(r => r.filename).length} PDF(s) disponível(is) na sessão.`;
  } catch(e) { ocrStatus.textContent = `Falha: ${e.message}`; }
  finally { stopBusy(); ocrBusy = false; updateOcrButton(); }
});
ocrDownload.addEventListener("click", () => {window.location.href = "/api/ocr/baixar";});
document.getElementById("ocr-clear").addEventListener("click", async () => {
  if (!confirm("Apagar os PDFs temporários desta sessão?")) return;
  const response = await fetch("/api/ocr/limpar", {method:"POST"});
  if (!response.ok) {ocrStatus.textContent = "Não foi possível limpar a sessão."; return;}
  ocrRecords = []; selectedOcrId = null; ocrViewer.dataset.currentId = ""; showOcrRecords(); ocrStatus.textContent = "Sessão limpa.";
});
fetch("/api/ocr/arquivos").then(r => r.json()).then(data => {ocrRecords = data.arquivos || [];showOcrRecords();}).catch(() => {});
