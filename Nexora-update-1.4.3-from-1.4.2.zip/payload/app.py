from flask import Flask, render_template, request, jsonify, Response, send_file, session, abort
from processor.xml_reader import parse_nfe, parse_cancelamento
import csv
import io
import re
import zipfile
import unicodedata
from pathlib import PurePath, Path
from uuid import uuid4
from threading import RLock, Thread
import os
import json
import tempfile
import shutil
import subprocess
import time
from processor.archive_reader import iter_xml_documents, ArchiveError
from processor.organization_refs import indexar_referencias

app = Flask(__name__)
app.secret_key = os.environ.get("NEXORA_SECRET") or os.environ.get("XANALYZER_SECRET") or os.urandom(32)
DESKTOP_MODE = os.environ.get("NEXORA_DESKTOP", os.environ.get("XANALYZER_DESKTOP")) == "1"
WORK_ROOT = Path(os.environ.get("NEXORA_WORK_ROOT") or os.environ.get("XANALYZER_WORK_ROOT") or (Path(tempfile.gettempdir()) / "nexora_ocr_work"))
WORK_ROOT.mkdir(parents=True, exist_ok=True)
work_lock = RLock()

app.config["MAX_CONTENT_LENGTH"] = 500 * 1024 * 1024  # 500 MB por requisição

if DESKTOP_MODE:
    app.config["TRUSTED_HOSTS"] = ["127.0.0.1"]
    app.config["SESSION_COOKIE_SAMESITE"] = "Strict"

    @app.before_request
    def guard_local_requests():
        # Impede POSTs originados por sites externos ao processo local.
        origin = request.headers.get("Origin")
        if origin and origin != request.host_url.rstrip("/"):
            abort(403)
        if request.headers.get("Sec-Fetch-Site") == "cross-site":
            abort(403)

@app.get("/")
def index():
    version = (Path(__file__).resolve().parent / "version.txt").read_text(encoding="utf-8").strip()
    return render_template("index.html", desktop=DESKTOP_MODE, version=version)

@app.get("/api/preferencias/tema")
def consultar_tema():
    from processor.ui_preferences import load_theme
    return jsonify({"theme": load_theme()})


@app.post("/api/preferencias/tema")
def alterar_tema():
    from processor.ui_preferences import save_theme
    value = (request.get_json(silent=True) or {}).get("theme")
    try:
        theme = save_theme(value)
    except ValueError as exc:
        return jsonify({"erro": str(exc)}), 400
    except OSError as exc:
        return jsonify({"erro": f"Não foi possível salvar o tema: {exc}"}), 500
    return jsonify({"theme": theme})


@app.post("/api/analisar")
def analisar():
    uploaded = request.files.getlist("arquivos")
    if not uploaded or all(not f.filename for f in uploaded):
        return jsonify({"erro": "Selecione ao menos um arquivo XML."}), 400

    linhas = []
    notas = []
    erros = []
    notas_lidas = 0
    # Eventos podem vir antes ou depois da NF, inclusive dentro de ZIP/7z.
    cancelamentos = {}
    eventos_sem_nota = 0

    for arquivo in uploaded:
        try:
            documents = iter_xml_documents(arquivo)
            for nome, conteudo in documents:
                try:
                    evento = parse_cancelamento(conteudo)
                    if evento is not None:
                        if evento["confirmado"]:
                            chave = evento["chave_acesso"]
                            ambiente = evento["ambiente"]
                            cancelamentos[(chave, ambiente)] = evento
                        else:
                            erros.append({"arquivo": nome, "erro": (
                                "Evento de cancelamento não confirmado: "
                                f"cStat={evento['codigo'] or 'ausente'}; {evento['motivo']}. "
                                "A nota não será marcada como cancelada."
                            )})
                        continue
                    nota = parse_nfe(conteudo)
                    if not nota["produtos"]:
                        erros.append({"arquivo": nome, "erro": "Nenhum produto (det/prod) encontrado."})
                        continue
                    total_nf_calculado = sum(item["valor_total_produto"] for item in nota["produtos"])
                    produtos_da_nota = []
                    for item in nota["produtos"]:
                        linha = {
                            "numero_nf": nota["numero_nf"],
                            "chave_acesso": nota["chave_acesso"],
                            "ambiente": nota["ambiente"],
                            "uf": nota["uf"],
                            "data_emissao": nota["data_emissao"],
                            "razao_social": nota["razao_social"],
                            "cfop": item["cfop"],
                            "nome_produto": item["nome_produto"],
                            "quantidade": item["quantidade"],
                            "valor_unitario": item["valor_unitario"],
                            "valor_total_produto": item["valor_total_produto"],
                            "valor_total_nf": total_nf_calculado,
                            "dados_adicionais": nota["dados_adicionais"],
                        }
                        linhas.append(linha)
                        produtos_da_nota.append({
                            "nome_produto": item["nome_produto"],
                            "cfop": item["cfop"],
                            "quantidade": item["quantidade"],
                            "valor_unitario": item["valor_unitario"],
                            "valor_total_produto": item["valor_total_produto"],
                        })
                    notas.append({
                        "numero_nf": nota["numero_nf"],
                        "chave_acesso": nota["chave_acesso"],
                        "ambiente": nota["ambiente"],
                        "uf": nota["uf"],
                        "data_emissao": nota["data_emissao"],
                        "razao_social": nota["razao_social"],
                        "cfops": sorted(set(prod["cfop"] for prod in produtos_da_nota if prod["cfop"])),
                        "valor_total_nf": total_nf_calculado,
                        "dados_adicionais": nota["dados_adicionais"],
                        "produtos": produtos_da_nota,
                    })
                    notas_lidas += 1
                except Exception as exc:
                    erros.append({"arquivo": nome, "erro": str(exc)})
        except (ArchiveError, ValueError, OSError) as exc:
            erros.append({"arquivo": arquivo.filename or "arquivo", "erro": str(exc)})

    # Só uma chave de acesso idêntica vincula o evento à NF, jamais o número.
    cancelamentos_usados = set()
    notas_canceladas = 0
    for nota in notas:
        chave = nota.get("chave_acesso")
        ambiente = nota.get("ambiente", "")
        evento = cancelamentos.get((chave, ambiente)) if chave else None
        # XMLs antigos podem não informar tpAmb; aceitamos correspondência
        # apenas se a chave for exata e o ambiente não contradiz o evento.
        if not evento and chave and not ambiente:
            matches = [(key, val) for key, val in cancelamentos.items() if key[0] == chave]
            if len(matches) == 1:
                evento = matches[0][1]
        if evento:
            notas_canceladas += 1
            cancelamentos_usados.add((evento["chave_acesso"], evento["ambiente"]))
            nota["situacao_nf"] = "Cancelada"
            nota["data_cancelamento"] = evento["data_cancelamento"]
            nota["protocolo_cancelamento"] = evento["protocolo_cancelamento"]
        else:
            # Não ter evento importado NÃO é prova de autorização/atividade.
            nota["situacao_nf"] = "Não verificada"
            nota["data_cancelamento"] = ""
            nota["protocolo_cancelamento"] = ""
    for linha in linhas:
        chave = linha.get("chave_acesso")
        ambiente = linha.get("ambiente", "")
        evento = cancelamentos.get((chave, ambiente)) if chave else None
        if not evento and chave and not ambiente:
            matches = [val for key, val in cancelamentos.items() if key[0] == chave]
            if len(matches) == 1:
                evento = matches[0]
        linha["situacao_nf"] = "Cancelada" if evento else "Não verificada"
        linha["data_cancelamento"] = evento["data_cancelamento"] if evento else ""
    eventos_sem_nota = len(cancelamentos) - len(cancelamentos_usados)
    return jsonify({
        "linhas": linhas,
        "notas": notas,
        "notas_lidas": notas_lidas,
        "notas_canceladas": notas_canceladas,
        "eventos_sem_nota": eventos_sem_nota,
        "produtos_lidos": len(linhas),
        "erros": erros,
    })

def numero_normalizado(value):
    value = str(value).strip()
    return str(int(value)) if value.isdigit() else None


def nome_pasta(value):
    value = unicodedata.normalize("NFC", value or "")
    value = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", value)
    value = value.strip(" .")
    if not value or value.upper() in {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)), *(f"LPT{i}" for i in range(1, 10))}:
        return "Destinatario_sem_nome"
    return value[:120].rstrip(" .")


def numero_pdf(filename):
    # Somente nomes com um número isolado, ou com prefixo NF/NFe.
    stem = PurePath(filename.replace("\\", "/")).stem
    explicit = re.findall(r"(?i)(?<![a-z0-9])nf(?:-?e)?\s*[-_#º°.:]*\s*0*(\d{1,9})(?!\d)", stem)
    if len(set(explicit)) == 1:
        return numero_normalizado(explicit[0])
    if explicit:
        return None
    simple = re.fullmatch(r"\s*0*(\d{1,9})\s*", stem)
    return numero_normalizado(simple.group(1)) if simple else None


def current_workdir(create=False):
    key = session.get("ocr_workspace")
    if not key and create:
        key = uuid4().hex
        session["ocr_workspace"] = key
    if not key or not re.fullmatch(r"[a-f0-9]{32}", key):
        return None
    path = WORK_ROOT / key
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path if path.exists() else None


def load_manifest(folder):
    path = folder / "manifest.json"
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else []


def save_manifest(folder, records):
    (folder / "manifest.json").write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8")


def unique_pdf_name(folder, wanted, except_id=None, records=None):
    wanted = PurePath(wanted.replace("\\", "/")).name
    if not wanted.lower().endswith(".pdf"):
        wanted += ".pdf"
    stem = PurePath(wanted).stem
    suffix = 2
    taken = {r["filename"].casefold() for r in (records or []) if r["id"] != except_id}
    while wanted.casefold() in taken:
        wanted = f"{stem} ({suffix}).pdf"
        suffix += 1
    return wanted


# Trabalhos em andamento: o navegador consulta o progresso durante o OCR.
ocr_jobs = {}
job_lock = RLock()


def check_dependencies():
    """Valida executáveis reais, não apenas a presença de módulos Python."""
    from processor.ocr_reader import resolve_executables
    return resolve_executables()


@app.get("/api/ocr/configuracoes")
def ocr_configuracoes():
    from processor.ocr_reader import load_ocr_settings
    return jsonify(load_ocr_settings())


@app.post("/api/ocr/configuracoes")
def salvar_ocr_configuracoes():
    from processor.ocr_reader import save_ocr_settings, resolve_executables
    data = request.get_json(silent=True) or {}
    tesseract = data.get("tesseract_path", "")
    poppler = data.get("poppler_path", "")
    if not isinstance(tesseract, str) or not isinstance(poppler, str):
        return jsonify({"erro": "Os caminhos devem ser textos."}), 400
    if len(tesseract) > 2048 or len(poppler) > 2048:
        return jsonify({"erro": "Caminho muito longo."}), 400
    try:
        save_ocr_settings(tesseract, poppler)
    except OSError as exc:
        return jsonify({"erro": f"Não foi possível salvar as configurações: {exc}"}), 500
    return jsonify({"salvo": True, "dependencias": resolve_executables()})


@app.get("/api/dependencias")
def dependencias():
    result = check_dependencies()
    return jsonify(result)


def update_job(job_id, **values):
    with job_lock:
        if job_id in ocr_jobs:
            ocr_jobs[job_id].update(values)


def ocr_worker(job_id, folder, inputs):
    from processor.ocr_reader import extract_invoice_number
    from processor.pdf_splitter import split_pdf_pages
    processed = 0
    failures = 0
    try:
        # Pré-divisão: permite informar a quantidade real de páginas a processar.
        pages_by_file = []
        total_pages = 0
        for idx, (original, path) in enumerate(inputs, start=1):
            update_job(job_id, mensagem=f"Separando páginas: {idx}/{len(inputs)}", etapa="divisao")
            try:
                pages = split_pdf_pages(path.read_bytes())
                pages_by_file.append((original, pages, None))
                total_pages += len(pages)
            except Exception as exc:
                failures += 1
                pages_by_file.append((original, [], str(exc)))
            update_job(job_id, percentual=round(15 * idx / len(inputs)))
        with work_lock:
            records = load_manifest(folder)
            for original, pages, error in pages_by_file:
                if error:
                    records.append({"id": uuid4().hex, "original": original, "filename": "", "numero_nf": "", "status": "erro", "erro": f"Falha na divisão: {error}", "pagina": None, "total_paginas": 0})
            save_manifest(folder, records)
        if not total_pages:
            raise ValueError("Nenhuma página válida foi encontrada nos PDFs.")
        for original, pages, error in pages_by_file:
            for page_number, page_data in enumerate(pages, 1):
                identifier = uuid4().hex
                (folder / f"{identifier}.pdf").write_bytes(page_data)
                update_job(job_id, etapa="ocr", mensagem=f"OCR: página {processed + 1} de {total_pages}")
                try:
                    number = extract_invoice_number(page_data)
                    issue = "" if number else "Número não identificado pelo OCR"
                except Exception as exc:
                    number, issue = None, str(exc)
                with work_lock:
                    records = load_manifest(folder)
                    filename = unique_pdf_name(folder, f"NF {number}.pdf" if number else f"{PurePath(original).stem}_pagina_{page_number}.pdf", records=records)
                    records.append({"id": identifier, "original": original, "filename": filename, "numero_nf": number or "", "status": "identificado" if number else "conferir", "erro": issue, "pagina": page_number, "total_paginas": len(pages)})
                    save_manifest(folder, records)
                processed += 1
                update_job(job_id, percentual=15 + round(85 * processed / total_pages), processadas=processed, total=total_pages)
        update_job(job_id, concluido=True, percentual=100, mensagem=f"Concluído: {processed} página(s); {failures} arquivo(s) inválido(s).", falhas=failures)
    except Exception as exc:
        update_job(job_id, concluido=True, erro=str(exc), mensagem="Processamento interrompido")
    finally:
        for _, path in inputs:
            path.unlink(missing_ok=True)


@app.post("/api/ocr/processar")
def ocr_processar():
    files = [f for f in request.files.getlist("pdfs") if f.filename]
    if not files:
        return jsonify({"erro": "Selecione PDFs para processamento."}), 400
    deps = check_dependencies()
    if not deps["ok"]:
        return jsonify({"erro": "Dependências indisponíveis. " + "; ".join(x["mensagem"] for x in deps["itens"] if not x["ok"])}), 503
    folder = current_workdir(create=True)
    with job_lock:
        active = any(j.get("workspace") == folder.name and not j.get("concluido") for j in ocr_jobs.values())
        if active:
            return jsonify({"erro": "Já existe um OCR em andamento nesta sessão."}), 409
    inputs = []
    for f in files:
        original = PurePath(f.filename.replace("\\", "/")).name
        if original.lower().endswith(".pdf"):
            path = folder / ("upload_" + uuid4().hex + ".pdf")
            f.save(path)
            inputs.append((original, path))
    if not inputs:
        return jsonify({"erro": "Nenhum arquivo PDF válido selecionado."}), 400
    job_id = uuid4().hex
    with job_lock:
        ocr_jobs[job_id] = {"workspace": folder.name, "percentual": 0, "mensagem": "Iniciando divisão...", "etapa": "divisao", "concluido": False, "processadas": 0, "total": 0, "erro": "", "criado": time.time()}
    Thread(target=ocr_worker, args=(job_id, folder, inputs), daemon=True).start()
    return jsonify({"job_id": job_id}), 202


@app.get("/api/ocr/progresso/<job_id>")
def ocr_progresso(job_id):
    folder = current_workdir()
    with job_lock:
        job = ocr_jobs.get(job_id)
        if not folder or not job or job["workspace"] != folder.name:
            abort(404)
        result = {k: v for k, v in job.items() if k not in ("workspace", "criado")}
    return jsonify(result)


@app.get("/api/ocr/arquivos")
def ocr_arquivos():
    folder = current_workdir()
    return jsonify({"arquivos": load_manifest(folder) if folder else []})


@app.get("/api/ocr/pdf/<identifier>")
def ocr_pdf(identifier):
    folder = current_workdir()
    if not folder or not re.fullmatch(r"[a-f0-9]{32}", identifier):
        abort(404)
    if not any(r["id"] == identifier for r in load_manifest(folder)):
        abort(404)
    path = folder / f"{identifier}.pdf"
    if not path.is_file():
        abort(404)
    if DESKTOP_MODE:
        # WebViews nem sempre oferecem visualizador PDF embutido.
        from processor.ocr_reader import render_preview
        try:
            preview = render_preview(path.read_bytes())
        except Exception:
            return Response("Não foi possível renderizar a página. Verifique o Poppler.", status=500, mimetype="text/plain")
        response = send_file(preview, mimetype="image/png")
        response.headers["Cache-Control"] = "no-store"
        return response
    response = send_file(path, mimetype="application/pdf", as_attachment=False, download_name="conferencia.pdf")
    response.headers["Content-Security-Policy"] = "default-src 'none'; sandbox"
    response.headers["Cache-Control"] = "no-store"
    return response


@app.post("/api/ocr/renomear/<identifier>")
def ocr_renomear(identifier):
    data = request.get_json(silent=True) or {}
    number = numero_normalizado(data.get("numero_nf", ""))
    if not number or len(number) > 9 or number == "0":
        return jsonify({"erro": "Informe um número de NF válido (até 9 dígitos)."}), 400
    with work_lock:
        folder = current_workdir()
        if not folder:
            abort(404)
        records = load_manifest(folder)
        record = next((r for r in records if r["id"] == identifier and (folder / f"{identifier}.pdf").is_file()), None)
        if not record:
            abort(404)
        record["numero_nf"] = number
        record["filename"] = unique_pdf_name(folder, f"NF {number}.pdf", except_id=identifier, records=records)
        record["status"] = "corrigido"
        record["erro"] = ""
        save_manifest(folder, records)
    return jsonify({"arquivo": record})


@app.get("/api/ocr/baixar")
def ocr_baixar():
    folder = current_workdir()
    if not folder:
        return jsonify({"erro": "Nenhum PDF disponível."}), 400
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as z:
        for record in load_manifest(folder):
            path = folder / f"{record['id']}.pdf"
            if path.is_file():
                z.write(path, record["filename"])
    output.seek(0)
    return send_file(output, mimetype="application/zip", as_attachment=True, download_name="pdfs_renomeados.zip")


@app.post("/api/ocr/limpar")
def ocr_limpar():
    with work_lock:
        folder = current_workdir()
        with job_lock:
            if folder and any(j.get("workspace") == folder.name and not j.get("concluido") for j in ocr_jobs.values()):
                return jsonify({"erro": "Aguarde o OCR terminar antes de limpar."}), 409
        if folder:
            shutil.rmtree(folder)
        session.pop("ocr_workspace", None)
    return jsonify({"ok": True})


@app.post("/api/organizar-pdfs")
def organizar_pdfs():
    xmls = [f for f in request.files.getlist("xmls") if f.filename]
    pdfs = [f for f in request.files.getlist("pdfs") if f.filename]
    use_ocr = request.form.get("origem") == "ocr"
    folder = current_workdir() if use_ocr else None
    stored = load_manifest(folder) if folder else []
    if not xmls or (not pdfs and not (use_ocr and stored)):
        return jsonify({"erro": "Selecione XMLs e PDFs, ou use os PDFs processados pelo OCR."}), 400

    # Aceita XML avulso e lotes ZIP/7z, inclusive com XMLs em subpastas.
    indice, erros_xml, xmls_validos = indexar_referencias(xmls, numero_normalizado)
    if not xmls_validos:
        detalhe = erros_xml[0] if erros_xml else "Nenhum XML de NF-e válido foi encontrado."
        return jsonify({"erro": f"Nenhuma NF-e de referência válida encontrada. {detalhe}"}), 400

    resultado = {"organizados": 0, "nao_identificados": 0, "ambiguos": 0, "xmls_referencia_validos": xmls_validos, "xmls_invalidos": erros_xml, "arquivos": []}
    buffer = io.BytesIO()
    usados = set()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as zip_out:
        sources = [(PurePath(f.filename.replace("\\", "/")).name, f.read()) for f in pdfs if f.filename.lower().endswith(".pdf")]
        if use_ocr:
            sources = [(r["filename"], (folder / f"{r['id']}.pdf").read_bytes()) for r in stored if r.get("filename") and (folder / f"{r['id']}.pdf").is_file()]
        for original, pdf_data in sources:
            numero = numero_pdf(original)
            destinatarios = indice.get(numero, set()) if numero else set()
            if len(destinatarios) == 1 and next(iter(destinatarios)):
                pasta = nome_pasta(next(iter(destinatarios)))
                status = "organizado"
                resultado["organizados"] += 1
            elif len(destinatarios) > 1:
                pasta = "Ambiguos"
                status = "ambiguo"
                resultado["ambiguos"] += 1
            else:
                pasta = "Nao_identificados"
                status = "nao_identificado"
                resultado["nao_identificados"] += 1
            # Evita colisões e sobrescritas no ZIP, inclusive nomes iguais.
            base = PurePath(original).stem
            ext = PurePath(original).suffix
            destino = f"{pasta}/{original}"
            contador = 2
            while destino.casefold() in usados:
                destino = f"{pasta}/{base} ({contador}){ext}"
                contador += 1
            usados.add(destino.casefold())
            zip_out.writestr(destino, pdf_data)
            resultado["arquivos"].append({"pdf": original, "numero_nf": numero, "pasta": pasta, "status": status})
        zip_out.writestr("relatorio_organizacao.json", __import__("json").dumps(resultado, ensure_ascii=False, indent=2))
    buffer.seek(0)
    return send_file(buffer, mimetype="application/zip", as_attachment=True, download_name="pdfs_por_razao_social.zip")


# Captura apenas o valor após a expressão de destino, sem alcançar o FCP.
_DIFAL_DESTINO = re.compile(
    r"\bDIFAL\s+da\s+UF\s+destino\b\s*[:=–—-]?\s*(?:R\s*\$\s*)?"
    r"(?P<valor>(?:[0-9]{1,3}(?:\.[0-9]{3})+|[0-9]+),[0-9]{2})(?![\d,]|\.[0-9]|\s*%)",
    re.IGNORECASE,
)


def extrair_difal(dados_adicionais):
    if not isinstance(dados_adicionais, str):
        return ""
    match = _DIFAL_DESTINO.search(dados_adicionais)
    # Sem R$ nem separador de milhares: número compatível com Excel pt-BR.
    return match.group("valor").replace(".", "") if match else ""


@app.post("/api/exportar")
def exportar():
    dados = request.get_json(silent=True) or {}
    notas = dados.get("notas", [])
    if not isinstance(notas, list) or not notas or not all(
        isinstance(nota, dict)
        and isinstance(nota.get("produtos"), list)
        and nota["produtos"]
        and all(isinstance(produto, dict) for produto in nota["produtos"])
        for nota in notas
    ):
        return jsonify({"erro": "Não há dados para exportar."}), 400

    colunas = [
        ("numero_nf", "Número da NF"),
        ("uf", "UF"),
        ("razao_social", "Cliente (Razão Social)"),
        ("cfop", "CFOP"),
        ("data_emissao", "Data de Emissão"),
        ("situacao_nf", "Situação da NF"),
        ("data_cancelamento", "Data do Cancelamento"),
        ("nome_produto", "Produto"),
        ("valor_unitario", "Valor unitário"),
        ("quantidade", "Quantidade"),
        ("difal", "DIFAL"),
        ("dados_adicionais", "Dados Adicionais"),
    ]

    buffer = io.StringIO(newline="")
    writer = csv.writer(buffer, delimiter=";", lineterminator="\r\n")
    writer.writerow([titulo for _, titulo in colunas])
    for nota in notas:
        linha = dict(nota)
        data = str(nota.get("data_emissao") or "")
        match = re.match(r"^(\d{4})-(\d{2})-(\d{2})", data)
        linha["data_emissao"] = f"{match[3]}/{match[2]}/{match[1]}" if match else data
        cancelamento = str(nota.get("data_cancelamento") or "")
        match_cancel = re.match(r"^(\d{4})-(\d{2})-(\d{2})", cancelamento)
        linha["data_cancelamento"] = (f"{match_cancel[3]}/{match_cancel[2]}/{match_cancel[1]}"
                                       if match_cancel else cancelamento)
        # A situação exportada reflete a análise documental desta sessão;
        # não substitui consulta online nem autenticação do XML.
        linha["situacao_nf"] = ("Cancelada" if nota.get("situacao_nf") == "Cancelada"
                                else "Não verificada")
        if linha["situacao_nf"] != "Cancelada":
            linha["data_cancelamento"] = ""
        difal = extrair_difal(nota.get("dados_adicionais"))
        for indice, produto in enumerate(nota["produtos"]):
            # Uma linha por item, com os dados da NF e o CFOP específico do produto.
            item = {**linha, **produto}
            # O DIFAL é total da NF, não do item; não duplica no somatório.
            item["difal"] = difal if indice == 0 else ""
            for campo in ("valor_unitario", "quantidade"):
                if isinstance(item.get(campo), (int, float)):
                    item[campo] = str(item[campo]).replace(".", ",")
            writer.writerow([item.get(chave, "") for chave, _ in colunas])

    # BOM para o Excel reconhecer UTF-8 e preservar acentos.
    conteudo = "\ufeff" + buffer.getvalue()
    return Response(
        conteudo,
        mimetype="text/csv; charset=utf-8",
        headers={"Content-Disposition": 'attachment; filename="analise_nfe.csv"'}
    )

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
